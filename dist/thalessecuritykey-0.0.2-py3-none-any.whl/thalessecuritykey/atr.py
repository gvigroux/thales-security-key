

class ATR(object):
    def __init__(self, name, pattern, mask):
        self.name = name
        self.pattern  = pattern
        self.mask     = mask
        self.result   = bin(pattern & mask)[2:]
    
    def isValid(self, ATR):
        if( bin(int(ATR.hex(), 16) & self.mask)[2:] == self.result ):
            return True
        return False