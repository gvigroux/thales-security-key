from thalessecuritykey.device import ThalesDevice
from unittest import mock

def test_pcsc_call_cbor():
    ThalesDevice("Mock")