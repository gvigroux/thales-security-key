import click
from smartcard.CardConnection import CardConnection
from smartcard.pcsc.PCSCCardConnection import PCSCCardConnection

from ThalesDevice import ThalesDevice



class PcscThalesCardConnection(PCSCCardConnection):

    dump = False
    
    def __init__(self, reader, dump=False):
        super().__init__(reader)
        self.dump = dump
        # TODO: change for self.addObserver()

    def transmit(self, data, protocol = None):
        color = 90
        if( self.dump ):
            click.secho("Request      " + ThalesDevice.hex(data), fg=color)

        data, SW1, SW2 = super().transmit(data,protocol)
        
        if ( SW1 == 0x61 ): # Success & Response bytes still available
            pass
        elif (SW1, SW2) != (0x90, 0x00):
            color = 'red'

        if (self.dump):
            click.secho("Response", fg=color)
            click.secho("    Data   : " + ThalesDevice.hex(data), fg=color)
            click.secho("    SW1 SW2: " + ThalesDevice.hex(SW1) + ThalesDevice.hex(SW2), fg=color)
            click.secho("", fg=color)
        return data, SW1, SW2

